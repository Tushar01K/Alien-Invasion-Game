# Alien-Invasion-Game-SJ
This Game is built For Enjoyment purpose only with python 

While Running If This Gives You Error Simply Install Packages And Run Main.py File Again


Dont Forget TO Change The File Location Path In Every File Where The IMG And Sound Uploaded

THANK YOU FOR VISIT 
